-- MySQL dump 10.13  Distrib 8.0.20, for Win64 (x86_64)
--
-- Host: localhost    Database: lib
-- ------------------------------------------------------
-- Server version	8.0.20

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Temporary view structure for view `books_view`
--

DROP TABLE IF EXISTS `books_view`;
/*!50001 DROP VIEW IF EXISTS `books_view`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `books_view` AS SELECT 
 1 AS `Издательство`,
 1 AS `Библиотека`,
 1 AS `Автор`,
 1 AS `Название`,
 1 AS `Кол-во страниц`,
 1 AS `Дата печати`,
 1 AS `Номер Издания`,
 1 AS `Статус`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `journals_view`
--

DROP TABLE IF EXISTS `journals_view`;
/*!50001 DROP VIEW IF EXISTS `journals_view`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `journals_view` AS SELECT 
 1 AS `Издательство`,
 1 AS `Библитека`,
 1 AS `Автор`,
 1 AS `Название`,
 1 AS `Кол-во страниц`,
 1 AS `Серия журнала`,
 1 AS `Номер выпуска`,
 1 AS `Статус`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `librarians_view`
--

DROP TABLE IF EXISTS `librarians_view`;
/*!50001 DROP VIEW IF EXISTS `librarians_view`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `librarians_view` AS SELECT 
 1 AS `ФИО Библиотекаря`,
 1 AS `Телефон Библиотекаря`,
 1 AS `Название Библиотеки`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `libraries_view`
--

DROP TABLE IF EXISTS `libraries_view`;
/*!50001 DROP VIEW IF EXISTS `libraries_view`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `libraries_view` AS SELECT 
 1 AS `Название Библиотеки`,
 1 AS `Город`,
 1 AS `Адрес`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `clients_view`
--

DROP TABLE IF EXISTS `clients_view`;
/*!50001 DROP VIEW IF EXISTS `clients_view`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `clients_view` AS SELECT 
 1 AS `ФИО Клиента`,
 1 AS `Телефон Клиента`,
 1 AS `Библиотека`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `authors_view`
--

DROP TABLE IF EXISTS `authors_view`;
/*!50001 DROP VIEW IF EXISTS `authors_view`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `authors_view` AS SELECT 
 1 AS `ФИО Автора`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `publishing_houses_view`
--

DROP TABLE IF EXISTS `publishing_houses_view`;
/*!50001 DROP VIEW IF EXISTS `publishing_houses_view`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `publishing_houses_view` AS SELECT 
 1 AS `Издательство`,
 1 AS `Адрес`,
 1 AS `Телефон`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `ebooks_view`
--

DROP TABLE IF EXISTS `ebooks_view`;
/*!50001 DROP VIEW IF EXISTS `ebooks_view`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `ebooks_view` AS SELECT 
 1 AS `Издательство`,
 1 AS `Библиотека`,
 1 AS `Автор`,
 1 AS `Название`,
 1 AS `Кол-во страниц`,
 1 AS `Формат`,
 1 AS `Размер`,
 1 AS `Статус`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `rentals_view`
--

DROP TABLE IF EXISTS `rentals_view`;
/*!50001 DROP VIEW IF EXISTS `rentals_view`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `rentals_view` AS SELECT 
 1 AS `Библитека`,
 1 AS `Библитекарь`,
 1 AS `Клиент`,
 1 AS `Название`,
 1 AS `Дата выдачи`,
 1 AS `Дата взврата`*/;
SET character_set_client = @saved_cs_client;

--
-- Final view structure for view `books_view`
--

/*!50001 DROP VIEW IF EXISTS `books_view`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_0900_ai_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `books_view` AS select `publishing_houses`.`PH_Name` AS `Издательство`,`libraries`.`Library_Name` AS `Библиотека`,concat(`authors`.`Author_SecondName`,' ',`authors`.`Author_FirstName`,' ',`authors`.`Author_Patronymic`) AS `Автор`,`readings`.`Read_Title` AS `Название`,`readings`.`Read_Pages` AS `Кол-во страниц`,`books`.`Book_PrintDate` AS `Дата печати`,`books`.`Book_PublNumber` AS `Номер Издания`,`readings`.`Read_Status` AS `Статус` from ((((`authors` join `publishing_houses`) join `readings`) join `books`) join `libraries`) where ((`authors`.`Author_Id` = `readings`.`Author_Id`) and (`publishing_houses`.`PH_Id` = `readings`.`PH_Id`) and (`libraries`.`Library_Id` = `readings`.`Library_Id`) and (`readings`.`Read_Id` = `books`.`Book_Id`)) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `journals_view`
--

/*!50001 DROP VIEW IF EXISTS `journals_view`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_0900_ai_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `journals_view` AS select `publishing_houses`.`PH_Name` AS `Издательство`,`libraries`.`Library_Name` AS `Библитека`,concat(`authors`.`Author_SecondName`,' ',`authors`.`Author_FirstName`,' ',`authors`.`Author_Patronymic`) AS `Автор`,`readings`.`Read_Title` AS `Название`,`readings`.`Read_Pages` AS `Кол-во страниц`,`journals`.`Journal_SeriesName` AS `Серия журнала`,`journals`.`Journal_IssueNumber` AS `Номер выпуска`,`readings`.`Read_Status` AS `Статус` from ((((`authors` join `readings`) join `journals`) join `libraries`) join `publishing_houses`) where ((`readings`.`Read_Id` = `journals`.`Journal_Id`) and (`readings`.`Library_Id` = `libraries`.`Library_Id`) and (`readings`.`Author_Id` = `authors`.`Author_Id`) and (`readings`.`PH_Id` = `publishing_houses`.`PH_Id`)) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `librarians_view`
--

/*!50001 DROP VIEW IF EXISTS `librarians_view`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_0900_ai_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `librarians_view` AS select concat(`librarians`.`Librarian_SecondName`,' ',`librarians`.`Librarian_FirstName`,' ',`librarians`.`Librarian_Patronymic`) AS `ФИО Библиотекаря`,`librarians`.`Librarian_Number` AS `Телефон Библиотекаря`,`libraries`.`Library_Name` AS `Название Библиотеки` from (`libraries` join `librarians`) where (`libraries`.`Library_Id` = `librarians`.`Library_Id`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `libraries_view`
--

/*!50001 DROP VIEW IF EXISTS `libraries_view`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_0900_ai_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `libraries_view` AS select `libraries`.`Library_Name` AS `Название Библиотеки`,`libraries`.`Library_City` AS `Город`,`libraries`.`Library_Address` AS `Адрес` from `libraries` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `clients_view`
--

/*!50001 DROP VIEW IF EXISTS `clients_view`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_0900_ai_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `clients_view` AS select concat(`clients`.`Client_SecondName`,' ',`clients`.`Client_FirstName`,' ',`clients`.`Client_Patronymic`) AS `ФИО Клиента`,`clients`.`Client_Number` AS `Телефон Клиента`,`libraries`.`Library_Name` AS `Библиотека` from (`libraries` join `clients`) where (`clients`.`Library_Id` = `libraries`.`Library_Id`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `authors_view`
--

/*!50001 DROP VIEW IF EXISTS `authors_view`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_0900_ai_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `authors_view` AS select concat(`authors`.`Author_SecondName`,' ',`authors`.`Author_FirstName`,' ',`authors`.`Author_Patronymic`) AS `ФИО Автора` from `authors` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `publishing_houses_view`
--

/*!50001 DROP VIEW IF EXISTS `publishing_houses_view`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_0900_ai_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `publishing_houses_view` AS select `publishing_houses`.`PH_Name` AS `Издательство`,`publishing_houses`.`PH_Address` AS `Адрес`,`publishing_houses`.`PH_Number` AS `Телефон` from `publishing_houses` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `ebooks_view`
--

/*!50001 DROP VIEW IF EXISTS `ebooks_view`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_0900_ai_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `ebooks_view` AS select `publishing_houses`.`PH_Name` AS `Издательство`,`libraries`.`Library_Name` AS `Библиотека`,concat(`authors`.`Author_SecondName`,' ',`authors`.`Author_FirstName`,' ',`authors`.`Author_Patronymic`) AS `Автор`,`readings`.`Read_Title` AS `Название`,`readings`.`Read_Pages` AS `Кол-во страниц`,`ebooks`.`Ebook_Format` AS `Формат`,`ebooks`.`Ebook_Size` AS `Размер`,`readings`.`Read_Status` AS `Статус` from ((((`ebooks` join `readings`) join `authors`) join `libraries`) join `publishing_houses`) where ((`readings`.`Read_Id` = `ebooks`.`Ebook_Id`) and (`readings`.`Library_Id` = `libraries`.`Library_Id`) and (`readings`.`Author_Id` = `authors`.`Author_Id`) and (`readings`.`PH_Id` = `publishing_houses`.`PH_Id`)) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `rentals_view`
--

/*!50001 DROP VIEW IF EXISTS `rentals_view`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_0900_ai_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `rentals_view` AS select `libraries`.`Library_Name` AS `Библитека`,concat(`librarians`.`Librarian_SecondName`,' ',`librarians`.`Librarian_FirstName`,' ',`librarians`.`Librarian_Patronymic`) AS `Библитекарь`,concat(`clients`.`Client_SecondName`,' ',`clients`.`Client_FirstName`,' ',`clients`.`Client_Patronymic`) AS `Клиент`,`readings`.`Read_Title` AS `Название`,`rentals`.`Rent_StartDate` AS `Дата выдачи`,`rentals`.`Rent_ReturnDate` AS `Дата взврата` from ((((`libraries` join `librarians`) join `clients`) join `readings`) join `rentals`) where ((`libraries`.`Library_Id` = `rentals`.`Library_Id`) and (`librarians`.`Librarian_Id` = `rentals`.`Librarian_Id`) and (`clients`.`Client_Id` = `rentals`.`Client_Id`) and (`readings`.`Read_Id` = `rentals`.`Read_id`)) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Dumping events for database 'lib'
--

--
-- Dumping routines for database 'lib'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-06-17 21:32:55
