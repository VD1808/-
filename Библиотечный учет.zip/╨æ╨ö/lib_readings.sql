-- MySQL dump 10.13  Distrib 8.0.20, for Win64 (x86_64)
--
-- Host: localhost    Database: lib
-- ------------------------------------------------------
-- Server version	8.0.20

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `readings`
--

DROP TABLE IF EXISTS `readings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `readings` (
  `Read_Id` int NOT NULL AUTO_INCREMENT,
  `PH_Id` int NOT NULL,
  `Library_Id` int NOT NULL,
  `Author_Id` int NOT NULL,
  `Read_Title` varchar(45) NOT NULL,
  `Read_Pages` int NOT NULL,
  `Read_Status` varchar(17) NOT NULL,
  PRIMARY KEY (`Read_Id`),
  KEY `Publisher_idx` (`PH_Id`),
  KEY `Author_idx` (`Author_Id`),
  KEY `Library_idx` (`Library_Id`),
  CONSTRAINT `Author` FOREIGN KEY (`Author_Id`) REFERENCES `authors` (`Author_Id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `Library` FOREIGN KEY (`Library_Id`) REFERENCES `libraries` (`Library_Id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `Publisher` FOREIGN KEY (`PH_Id`) REFERENCES `publishing_houses` (`PH_Id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `readings`
--

LOCK TABLES `readings` WRITE;
/*!40000 ALTER TABLE `readings` DISABLE KEYS */;
INSERT INTO `readings` VALUES (4,2,2,2,'Горе от ума',256,'Выдано'),(5,3,3,3,'Война и мир',3560,'Выдано'),(6,2,1,4,'Преступление и наказание',886,'В наличии'),(16,4,1,3,'История Франции',245,'Выдано');
/*!40000 ALTER TABLE `readings` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-06-17 21:32:33
