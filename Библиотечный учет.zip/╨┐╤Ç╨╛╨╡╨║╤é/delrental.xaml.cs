﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace LIBproject
{
    /// <summary>
    /// Логика взаимодействия для delrental.xaml
    /// </summary>
    public partial class delrental : Page
    {
        public delrental()
        {
            InitializeComponent();
            Books.ItemsSource = Connect.ChtoToForComboBox("books");
        }
        private void Button_Click_1(object sender, RoutedEventArgs e)//кнопка удаления записи
        {
            int Read_Id;
            string Id; 
                Read_Id = Convert.ToInt32(Books.SelectedValue);
                Id = Convert.ToString(Read_Id);
                if (Connect.GetId("Rent_Id", "rentals", "Read_Id", Id) != 0)
                {
                    Connect.DeleteRental(Id);
                }
                else
                {
                    MessageBox.Show("Книга с таким названием не в прокате");
                }                              //вызов класса из файла connect.cs

        }
    }
}
