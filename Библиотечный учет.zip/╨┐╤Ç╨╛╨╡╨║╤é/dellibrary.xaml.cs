﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace LIBproject
{
    /// <summary>
    /// Логика взаимодействия для dellibrary.xaml
    /// </summary>
    public partial class dellibrary : Page
    {
        public dellibrary()
        {
            InitializeComponent();
            libraries.ItemsSource = Connect.ChtoToForComboBox("libraries");
        }
        private void Button_Click_1(object sender, RoutedEventArgs e)//кнопка удаления записи
        {
                int id = Convert.ToInt32(libraries.SelectedValue);
                string Library_Id = Convert.ToString(id);
                Connect.DeleteLibrary(Library_Id);//вызов класса из файла connect.cs
        }
    }
}
