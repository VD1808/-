﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace LIBproject
{
    /// <summary>
    /// Логика взаимодействия для AddRental.xaml
    /// </summary>
    public partial class AddRental : Page
    {
        public AddRental()
        {
            InitializeComponent();
            clients.ItemsSource = Connect.ChtoToForComboBox("clients");
            librarians.ItemsSource = Connect.ChtoToForComboBox("librarians");
            redings.ItemsSource = Connect.ChtoToForComboBox("redings");
            libraries.ItemsSource = Connect.ChtoToForComboBox("libraries");
        }
        private void Button_Click_1(object sender, RoutedEventArgs e)//кнопка добавления записи
        {
                int Librarian_Id; int Library_Id; int Read_Id; int Client_Id;
                Librarian_Id = Convert.ToInt32(librarians.SelectedValue);
                Read_Id = Convert.ToInt32(redings.SelectedValue);
                Client_Id = Convert.ToInt32(clients.SelectedValue);
                Library_Id = Convert.ToInt32(libraries.SelectedValue);
                Connect.AddRental(TextBox1.Text, TextBox2.Text, Library_Id, Librarian_Id, Client_Id, Read_Id); //вызов класса из файла connect.cs
        }
    }
}
