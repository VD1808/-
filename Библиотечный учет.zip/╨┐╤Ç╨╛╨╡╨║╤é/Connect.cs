﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MySql.Data.MySqlClient;
using System.Data.Sql;
using LIBproject;
using System.Windows;
using System.Collections.ObjectModel;
using System.Data;

namespace LIBproject
{    
    public static class Connect
    {       
        public static String connString, connName;
        public static MySqlConnection connection = new MySqlConnection();
        public static MySqlCommand MySqlCommand;
        public static void CreateConnect(string a, string b, string c, string d, string e)
        {
            connName = a;
            connString = "server="+ b + ";uid="+d+";pwd="+e+ ";port=" + c + ";database=lib;";
            connection = new MySqlConnection(connString);
        }
        public static void OpenConnect()
        {
            connection.Open();
        }
        public static void AddLibrary( string Library_Name, string Library_City, string Library_Address)//Класс для добавления записи в таблицу libraries
        {
            try {
                connection = new MySqlConnection(connString);
                connection.Open();
                MySqlCommand cm = new MySqlCommand("INSERT INTO libraries (Library_Name, Library_City, Library_Address) VALUES (@Library_Name, @Library_City, @Library_Address)",
                connection);//Создание запроса
                cm.Parameters.Add("@Library_Name", MySqlDbType.VarChar, 40).Value = Convert.ToString(Library_Name);//добавление значений
                cm.Parameters.Add("@Library_City", MySqlDbType.VarChar, 20).Value = Convert.ToString(Library_City);
                cm.Parameters.Add("@Library_Address", MySqlDbType.VarChar, 30).Value = Convert.ToString(Library_Address);
                cm.ExecuteNonQuery();
                MessageBox.Show("Запись создана!");
            }
            catch {
                MessageBox.Show("Ошибка! Запись не создана!");
                  }
            CloseConnect();
        }
        public static void Addlibrarians(string librarian_SecondName, string librarian_FirstName, string librarian_Patronymic, string librarian_Number, int Library_Id)
        {
            try
            {
                connection = new MySqlConnection(connString);
                if (!Connect.connection.State.Equals(ConnectionState.Open)) connection.Open();
                MySqlCommand cm = new MySqlCommand("INSERT INTO librarians (librarian_SecondName, librarian_FirstName, librarian_Patronymic, librarian_Number, Library_Id)" +
                    " VALUES (@librarian_SecondName, @librarian_FirstName, @librarian_Patronymic, @librarian_Number, @Library_Id)", connection);//Создание запроса 
                cm.Parameters.Add("@librarian_SecondName", MySqlDbType.VarChar, 15).Value = Convert.ToString(librarian_SecondName);//добавление записей в таблицу librarians
                cm.Parameters.Add("@librarian_FirstName", MySqlDbType.VarChar, 15).Value = Convert.ToString(librarian_FirstName);
                cm.Parameters.Add("@librarian_Patronymic", MySqlDbType.VarChar, 15).Value = Convert.ToString(librarian_Patronymic);
                cm.Parameters.Add("@librarian_Number", MySqlDbType.VarChar, 11).Value = Convert.ToString(librarian_Number);
                cm.Parameters.Add("@Library_Id", MySqlDbType.Int32).Value = Convert.ToInt32(Library_Id);
                cm.ExecuteNonQuery();
                MessageBox.Show("Запись создана!");
            }
            catch
            {
                MessageBox.Show("Ошибка! Запись не создана!");
            }
            if (Connect.connection.State.Equals(ConnectionState.Open)) CloseConnect();
        }
        public static void AddAuthor( string Author_SecondName, string Author_FirstName, string Author_Patronymic)//Класс для добавления записи в таблицу authors
        {
            try {
                connection = new MySqlConnection(connString);
                connection.Open();
                MySqlCommand cm = new MySqlCommand("INSERT INTO authors (Author_SecondName, Author_FirstName, Author_Patronymic) VALUES (@Author_SecondName, @Author_FirstName, @Author_Patronymic)",
                connection);//Создание запроса
                cm.Parameters.Add("@Author_SecondName", MySqlDbType.VarChar, 15).Value = Convert.ToString(Author_SecondName);//добавление значений
                cm.Parameters.Add("@Author_FirstName", MySqlDbType.VarChar, 15).Value = Convert.ToString(Author_FirstName);
                cm.Parameters.Add("@Author_Patronymic", MySqlDbType.VarChar, 15).Value = Convert.ToString(Author_Patronymic);
                cm.ExecuteNonQuery();
                MessageBox.Show("Запись создана!");
            }
            catch
            {
                MessageBox.Show("Ошибка! Запись не создана!");
            }
            CloseConnect();
        }
        //Класс для добавления записи в таблицу books
        public static void AddBook(string Book_PrintDate, string Book_PublNumber, int PH_Id, int Library_Id, int Author_Id, string Read_Title, string Read_Pages)
        {
            try {
                string Read_Status = "В наличии";
                connection = new MySqlConnection(connString);
                if (!Connect.connection.State.Equals(ConnectionState.Open)) connection.Open();
                MySqlCommand cm = new MySqlCommand("INSERT INTO readings (PH_Id, Library_Id, Author_Id, Read_Title, Read_Pages, Read_Status) VALUES " +
                   "(@PH_Id, @Library_Id, @Author_Id, @Read_Title, @Read_Pages, 'В наличии')", connection);      //Создание запроса    
                cm.Parameters.Add("@PH_Id", MySqlDbType.Int32).Value = Convert.ToInt32(PH_Id);//добавление записей в таблицу readings
                cm.Parameters.Add("@Library_Id", MySqlDbType.Int32).Value = Convert.ToInt32(Library_Id);
                cm.Parameters.Add("@Author_Id", MySqlDbType.Int32).Value = Convert.ToInt32(Author_Id);
                cm.Parameters.Add("@Read_Title", MySqlDbType.VarChar, 45).Value = Convert.ToString(Read_Title);
                cm.Parameters.Add("@Read_Pages", MySqlDbType.Int32).Value = Convert.ToInt32(Read_Pages);
                cm.Parameters.Add("@Read_Status", MySqlDbType.VarChar, 17).Value = Convert.ToString(Read_Status);
                cm.ExecuteNonQuery();
                string sql = "SELECT Read_Id FROM readings WHERE Read_Title = '" + Read_Title + "' AND Read_Pages = '" + Read_Pages + "' ";//создание запроса для нахождения внешнего ключа книги
                int id;
                MySqlCommand cmd = new MySqlCommand(sql, Connect.connection);
                using (cmd)
                {
                    id = Convert.ToInt32(cmd.ExecuteScalar());
                }
                cmd.ExecuteNonQuery();
                // добавление записей в таблицу books
                MySqlCommand cmm = new MySqlCommand("INSERT INTO books (Book_Id, Book_PrintDate, Book_PublNumber) VALUES (@Book_Id, @Book_PrintDate, @Book_PublNumber)", connection);
                cmm.Parameters.Add("@Book_Id", MySqlDbType.Int32).Value = Convert.ToInt32(id);
                cmm.Parameters.Add("@Book_PrintDate", MySqlDbType.VarChar, 10).Value = Convert.ToString(Book_PrintDate);
                cmm.Parameters.Add("@Book_PublNumber", MySqlDbType.Int32).Value = Convert.ToInt32(Book_PublNumber);
                cmm.ExecuteNonQuery();
                MessageBox.Show("Запись создана!");
            }
             catch
            { MessageBox.Show("Ошибка! Запись не создана!"); }
            if (Connect.connection.State.Equals(ConnectionState.Open)) CloseConnect();
        }      
        //Класс для добавления записи в таблицу clients
        public static void AddClient(string Client_SecondName, string Client_FirstName, string Client_Patronymic, string Client_Number, int Library_Id)
        {
            try
            {
                connection = new MySqlConnection(connString);
                if (!Connect.connection.State.Equals(ConnectionState.Open)) connection.Open();
                MySqlCommand cm = new MySqlCommand("INSERT INTO clients (Client_SecondName, Client_FirstName, Client_Patronymic, Client_Number, Library_Id)" +
                    " VALUES (@Client_SecondName, @Client_FirstName, @Client_Patronymic, @Client_Number, @Library_Id)", connection);//Создание запроса
                cm.Parameters.Add("@Client_SecondName", MySqlDbType.VarChar, 15).Value = Convert.ToString(Client_SecondName);//добавление записей в таблицу clients
                cm.Parameters.Add("@Client_FirstName", MySqlDbType.VarChar, 15).Value = Convert.ToString(Client_FirstName);
                cm.Parameters.Add("@Client_Patronymic", MySqlDbType.VarChar, 15).Value = Convert.ToString(Client_Patronymic);
                cm.Parameters.Add("@Client_Number", MySqlDbType.VarChar, 11).Value = Convert.ToString(Client_Number);
                cm.Parameters.Add("@Library_Id", MySqlDbType.Int32).Value = Convert.ToInt32(Library_Id);
                cm.ExecuteNonQuery();
                MessageBox.Show("Запись создана!");
            }
            catch
            {
                MessageBox.Show("Ошибка! Запись не создана!");
            }
            if (Connect.connection.State.Equals(ConnectionState.Open)) CloseConnect();
        }
        //Класс для добавления записи в таблицу ebooks
        public static void AddEBook(string Ebook_Format, string Ebook_Size, int PH_Id, int Library_Id, int Author_Id, string Read_Title, string Read_Pages)
        {
            try
            {
                string Read_Status = "В наличии";
                connection = new MySqlConnection(connString);
                if (!Connect.connection.State.Equals(ConnectionState.Open)) connection.Open();
                MySqlCommand cm = new MySqlCommand("INSERT INTO readings (PH_Id, Library_Id, Author_Id, Read_Title, Read_Pages, Read_Status) VALUES " +
                   "(@PH_Id, @Library_Id, @Author_Id, @Read_Title, @Read_Pages, 'В наличии')", connection);//Создание запроса 
                cm.Parameters.Add("@PH_Id", MySqlDbType.Int32).Value = Convert.ToInt32(PH_Id);//добавление записей в таблицу readings
                cm.Parameters.Add("@Library_Id", MySqlDbType.Int32).Value = Convert.ToInt32(Library_Id);
                cm.Parameters.Add("@Author_Id", MySqlDbType.Int32).Value = Convert.ToInt32(Author_Id);
                cm.Parameters.Add("@Read_Title", MySqlDbType.VarChar, 45).Value = Convert.ToString(Read_Title);
                cm.Parameters.Add("@Read_Pages", MySqlDbType.Int32).Value = Convert.ToInt32(Read_Pages);
                cm.Parameters.Add("@Read_Status", MySqlDbType.VarChar, 17).Value = Convert.ToString(Read_Status);
                cm.ExecuteNonQuery();
                //создание запроса для нахождения внешнего ключа электронной книги
                string sql = "SELECT Read_Id FROM readings WHERE Read_Title = '" + Read_Title + "' AND Read_Pages = '" + Read_Pages + "' ";
                int id;
                MySqlCommand cmd = new MySqlCommand(sql, Connect.connection);
                using (cmd) 
                {
                    id = Convert.ToInt32(cmd.ExecuteScalar());                   
                }
                cmd.ExecuteNonQuery();
                // добавление записей в таблицу еbooks
                MySqlCommand cmm = new MySqlCommand("INSERT INTO ebooks (Ebook_Id, Ebook_Format, Ebook_Size) VALUES (@Ebook_Id, @Ebook_Format, @Ebook_Size)", connection);
                cmm.Parameters.Add("@Ebook_Id", MySqlDbType.Int32).Value = Convert.ToInt32(id);
                cmm.Parameters.Add("@Ebook_Format", MySqlDbType.VarChar, 10).Value = Convert.ToString(Ebook_Format);
                cmm.Parameters.Add("@Ebook_Size", MySqlDbType.Int32).Value = Convert.ToInt32(Ebook_Size);
                cmm.ExecuteNonQuery();
                MessageBox.Show("Запись создана!");
            }
            catch
            {
               MessageBox.Show("Ошибка! Запись не создана!");
            }
            if (Connect.connection.State.Equals(ConnectionState.Open)) CloseConnect();
        }      
        //Класс для добавления записи в таблицу journals
        public static void AddJournal(string Journal_SeriesName, string Journal_IssueNumber, int PH_Id, int Library_Id, int Author_Id, string Read_Title, string Read_Pages)
        {
            try
            {
                string Read_Status = "В наличии";
                connection = new MySqlConnection(connString);
                if (!Connect.connection.State.Equals(ConnectionState.Open)) connection.Open();
                MySqlCommand cm = new MySqlCommand("INSERT INTO readings (PH_Id, Library_Id, Author_Id, Read_Title, Read_Pages, Read_Status) VALUES " +
                   "(@PH_Id, @Library_Id, @Author_Id, @Read_Title, @Read_Pages, 'В наличии')", connection);//Создание запроса 
                cm.Parameters.Add("@PH_Id", MySqlDbType.Int32).Value = Convert.ToInt32(PH_Id);//добавление записей в таблицу readings
                cm.Parameters.Add("@Library_Id", MySqlDbType.Int32).Value = Convert.ToInt32(Library_Id);
                cm.Parameters.Add("@Author_Id", MySqlDbType.Int32).Value = Convert.ToInt32(Author_Id);
                cm.Parameters.Add("@Read_Title", MySqlDbType.VarChar, 45).Value = Convert.ToString(Read_Title);
                cm.Parameters.Add("@Read_Pages", MySqlDbType.Int32).Value = Convert.ToInt32(Read_Pages);
                cm.Parameters.Add("@Read_Status", MySqlDbType.VarChar, 17).Value = Convert.ToString(Read_Status);
                cm.ExecuteNonQuery();
                //создание запроса для нахождения внешнего ключа журнала
                string sql = "SELECT Read_Id FROM readings WHERE Read_Title = '" + Read_Title + "' AND Read_Pages = '" + Read_Pages + "' ";
                int id;
                MySqlCommand cmd = new MySqlCommand(sql, Connect.connection);
                using (cmd)
                {
                    id = Convert.ToInt32(cmd.ExecuteScalar());
                }
                cmd.ExecuteNonQuery();
                // добавление записей в таблицу journals
                MySqlCommand cmm = new MySqlCommand("INSERT INTO journals (Journal_Id, Journal_SeriesName, Journal_IssueNumber) VALUES (@Journal_Id, @Journal_SeriesName, @Journal_IssueNumber)",
                    connection);
                cmm.Parameters.Add("@Journal_Id", MySqlDbType.Int32).Value = Convert.ToInt32(id);//добавление записей в таблицу journals
                cmm.Parameters.Add("@Journal_SeriesName", MySqlDbType.VarChar, 45).Value = Convert.ToString(Journal_SeriesName);
                cmm.Parameters.Add("@Journal_IssueNumber", MySqlDbType.Int32).Value = Convert.ToInt32(Journal_IssueNumber);
                cmm.ExecuteNonQuery();
                MessageBox.Show("Запись создана!");
            }
            catch
            {
                MessageBox.Show("Ошибка! Запись не создана!");
            }
            if (Connect.connection.State.Equals(ConnectionState.Open)) CloseConnect();
        }
        //Класс для добавления записи в таблицу rentals
        public static void AddRental(string Rent_StartDate, string Rent_ReturnDate, int Library_Id, int Librarian_Id, int Client_Id, int Read_Id)
        {
            try
            {
                connection = new MySqlConnection(connString);
                if (!Connect.connection.State.Equals(ConnectionState.Open)) connection.Open();
                MySqlCommand cm = new MySqlCommand("INSERT INTO rentals (Library_Id, Librarian_Id, Client_Id, Read_Id, Rent_StartDate, Rent_ReturnDate)" +
                    " VALUES (@Library_Id, @Librarian_Id, @Client_Id, @Read_Id, @Rent_StartDate, @Rent_ReturnDate)", connection);//Создание запроса
                cm.Parameters.Add("@Library_Id", MySqlDbType.Int32).Value = Convert.ToInt32(Library_Id);//добавление записей в таблицу rentals
                cm.Parameters.Add("@Librarian_Id", MySqlDbType.Int32).Value = Convert.ToInt32(Librarian_Id);
                cm.Parameters.Add("@Client_Id", MySqlDbType.Int32).Value = Convert.ToInt32(Client_Id);
                cm.Parameters.Add("@Read_Id", MySqlDbType.Int32).Value = Convert.ToInt32(Read_Id);
                cm.Parameters.Add("@Rent_StartDate", MySqlDbType.VarChar, 10).Value = Convert.ToString(Rent_StartDate);
                cm.Parameters.Add("@Rent_ReturnDate", MySqlDbType.VarChar, 10).Value = Convert.ToString(Rent_ReturnDate);
                cm.ExecuteNonQuery();
                //Создание запроса для нахождения Read_Id
                string sql = "SELECT Read_Id FROM rentals WHERE Client_Id = '" + Client_Id + "' AND Rent_StartDate= '" + Rent_StartDate + "' AND Rent_ReturnDate= '" + Rent_ReturnDate +
                    "' AND Library_Id= '" + Library_Id + "' AND Librarian_Id= '" + Librarian_Id + "' ";
                int id;
                MySqlCommand cmd = new MySqlCommand(sql, Connect.connection);
                using (cmd)
                {
                    id = Convert.ToInt32(cmd.ExecuteScalar());
                }
                cmd.ExecuteNonQuery();
                //Изменение статуса книги после добавления записи в таблицу rentals
                MySqlCommand cmm = new MySqlCommand("UPDATE readings SET Read_Status='Выдано' WHERE Read_Id='" + id + "' ", connection); 
                cmm.ExecuteNonQuery();
                MessageBox.Show("Запись создана!");
           }
            catch
            {
               MessageBox.Show("Ошибка! Запись не создана!");
            }
            if (Connect.connection.State.Equals(ConnectionState.Open)) CloseConnect();
        }
        public static void DeleteAuthor(string Author_Id)//Класс для удаления записей из таблицы authors
        {
            try
            {
                connection = new MySqlConnection(connString);
                if (!Connect.connection.State.Equals(ConnectionState.Open)) connection.Open();              
                MySqlCommand cm = new MySqlCommand("DELETE FROM authors WHERE Author_Id = '" + Author_Id + "' ", connection);//Создание запроса
                cm.Parameters.Add("@Author_Id", MySqlDbType.Int32).Value = Convert.ToInt32(Author_Id);//удаление записей из таблицы authors
                cm.ExecuteNonQuery();
                MessageBox.Show("Запись Удалена!");
            }
            catch
            {
                MessageBox.Show("Ошибка! Запись не Удалена!");
            }
            if (Connect.connection.State.Equals(ConnectionState.Open)) CloseConnect();
        }
        public static void DeleteLibrary(string Library_Id)//Класс для удаления записей из таблицы libraries
        {
            try
            {
                connection = new MySqlConnection(connString);
                if (!Connect.connection.State.Equals(ConnectionState.Open)) connection.Open();
                MySqlCommand cm = new MySqlCommand("DELETE FROM libraries WHERE Library_Id = '" + Library_Id + "' ", connection);//Создание запроса
                cm.Parameters.Add("@Library_Id", MySqlDbType.Int32).Value = Convert.ToInt32(Library_Id);//удаление записей из таблицы libraries
                cm.ExecuteNonQuery();
                MessageBox.Show("Запись Удалена!");
            }
            catch
            {
                MessageBox.Show("Ошибка! Запись не Удалена!");
            }
            if (Connect.connection.State.Equals(ConnectionState.Open)) CloseConnect();
        }
        public static void DeleteLibrarian(string Librarian_Id)//Класс для удаления записей из таблицы librarians
        {
            try
            {
                connection = new MySqlConnection(connString);
                if (!Connect.connection.State.Equals(ConnectionState.Open)) connection.Open();
                MySqlCommand cm = new MySqlCommand("DELETE FROM librarians WHERE Librarian_Id = '" + Librarian_Id + "' ", connection);//Создание запроса
                cm.Parameters.Add("@Librarian_Id", MySqlDbType.Int32).Value = Convert.ToInt32(Librarian_Id);//удаление записей из таблицы librarians
                cm.ExecuteNonQuery();
                MessageBox.Show("Запись Удалена!");
            }
            catch
            {
                MessageBox.Show("Ошибка! Запись не Удалена!");
            }
            if (Connect.connection.State.Equals(ConnectionState.Open)) CloseConnect();
        }
        public static void DeleteClient(string Client_Id)//Класс для удаления записей из таблицы clients
        {
            try
            {
                connection = new MySqlConnection(connString);
                if (!Connect.connection.State.Equals(ConnectionState.Open)) connection.Open();
                MySqlCommand cm = new MySqlCommand("DELETE FROM clients WHERE Client_Id = '" + Client_Id + "' ", connection);//Создание запроса
                cm.Parameters.Add("@Client_Id", MySqlDbType.Int32).Value = Convert.ToInt32(Client_Id);//удаление записей из таблицы clients
                cm.ExecuteNonQuery();
                MessageBox.Show("Запись Удалена!");
            }
            catch
            {
                MessageBox.Show("Ошибка! Запись не Удалена!");
            }
            if (Connect.connection.State.Equals(ConnectionState.Open)) CloseConnect();
        }
        public static void DeletePH(string PH_Id)//Класс для удаления записей из таблицы publishing_houses
        {
            try
            {
                connection = new MySqlConnection(connString);
                if (!Connect.connection.State.Equals(ConnectionState.Open)) connection.Open();
                MySqlCommand cm = new MySqlCommand("DELETE FROM publishing_houses WHERE PH_Id = '" + PH_Id + "' ", connection);//Создание запроса
                cm.Parameters.Add("@PH_Id", MySqlDbType.Int32).Value = Convert.ToInt32(PH_Id);//удаление записей из таблицы publishing_houses
                cm.ExecuteNonQuery();
                MessageBox.Show("Запись Удалена!");
            }
            catch
            {
                MessageBox.Show("Ошибка! Запись не Удалена!");
            }
            if (Connect.connection.State.Equals(ConnectionState.Open)) CloseConnect();
        }
        public static void DeleteBook(string Book_Id)//Класс для удаления записей из таблицы books
        {
            try
            {
                connection = new MySqlConnection(connString);
                if (!Connect.connection.State.Equals(ConnectionState.Open)) connection.Open();
                MySqlCommand cm = new MySqlCommand("DELETE FROM books WHERE Book_Id = '" + Book_Id + "' ", connection);//Создание запроса
                cm.Parameters.Add("@Book_Id", MySqlDbType.Int32).Value = Convert.ToInt32(Book_Id);//удаление записей из таблицы books
                {
                    cm.ExecuteNonQuery();
                }
                MySqlCommand cmd = new MySqlCommand("DELETE FROM readings WHERE Read_Id = '" + Book_Id + "' ", connection);//Создание запроса
                cmd.Parameters.Add("@Read_Id", MySqlDbType.Int32).Value = Convert.ToInt32(Book_Id);//удаление записей из таблицы readings
                    cmd.ExecuteNonQuery();
                MessageBox.Show("Запись Удалена!");
            }
            catch
            {
                MessageBox.Show("Ошибка! Запись не Удалена!");
            }
            if (Connect.connection.State.Equals(ConnectionState.Open)) CloseConnect();
        }
        public static void DeleteEBook(string EBook_Id)//Класс для удаления записей из таблицы еbooks
        {
            try
            {
                connection = new MySqlConnection(connString);
                if (!Connect.connection.State.Equals(ConnectionState.Open)) connection.Open();
                MySqlCommand cm = new MySqlCommand("DELETE FROM ebooks WHERE Ebook_Id = '" + EBook_Id + "' ", connection);//Создание запроса
                cm.Parameters.Add("@Ebook_Id", MySqlDbType.Int32).Value = Convert.ToInt32(EBook_Id);//удаление записей из таблицы еbooks
                cm.ExecuteNonQuery();
                MySqlCommand cmd = new MySqlCommand("DELETE FROM readings WHERE Read_Id = '" + EBook_Id + "' ", connection);//Создание запроса
                cmd.Parameters.Add("@Read_Id", MySqlDbType.Int32).Value = Convert.ToInt32(EBook_Id);//удаление записей из таблицы readings
                cmd.ExecuteNonQuery();
                MessageBox.Show("Запись Удалена!");
            }
            catch
            {
                MessageBox.Show("Ошибка! Запись не Удалена!");
            }
            if (Connect.connection.State.Equals(ConnectionState.Open)) CloseConnect();
        }
        public static void DeleteJournal(string Journal_Id)//Класс для удаления записей из таблицы journals
        {
            try
            {
                connection = new MySqlConnection(connString);
                if (!Connect.connection.State.Equals(ConnectionState.Open)) connection.Open();
                MySqlCommand cm = new MySqlCommand("DELETE FROM journals WHERE Journal_Id = '" + Journal_Id + "' ", connection);//Создание запроса
                cm.Parameters.Add("@Journal_Id", MySqlDbType.Int32).Value = Convert.ToInt32(Journal_Id);//удаление записей из таблицы journals
                cm.ExecuteNonQuery();
                MySqlCommand cmd = new MySqlCommand("DELETE FROM readings WHERE Read_Id = '" + Journal_Id + "' ", connection);//Создание запроса
                cmd.Parameters.Add("@Read_Id", MySqlDbType.Int32).Value = Convert.ToInt32(Journal_Id);//удаление записей из таблицы readings
                cmd.ExecuteNonQuery();
                MessageBox.Show("Запись Удалена!");
            }
            catch
            {
                MessageBox.Show("Ошибка! Запись не Удалена!");
            }
            if (Connect.connection.State.Equals(ConnectionState.Open)) CloseConnect();
        }
        public static void DeleteRental(string Read_Id)//Класс для удаления записей из таблицы rentals
        {
            try
            {
                connection = new MySqlConnection(connString);
                if (!Connect.connection.State.Equals(ConnectionState.Open)) connection.Open();
                MySqlCommand cmd = new MySqlCommand("UPDATE readings SET Read_Status = 'В наличии' WHERE Read_Id = '" + Read_Id + "' ", connection);//Создание запроса
                cmd.Parameters.Add("@Read_Id", MySqlDbType.Int32).Value = Convert.ToInt32(Read_Id);//редактирование записи в таблице readings
                cmd.ExecuteNonQuery();
                MySqlCommand cm = new MySqlCommand("DELETE FROM rentals WHERE Read_Id = '" + Read_Id + "' ", connection);//Создание запрос
                cm.Parameters.Add("@Read_Id", MySqlDbType.Int32).Value = Convert.ToInt32(Read_Id);//удаление записи в табилице rentals
                cm.ExecuteNonQuery();               
                MessageBox.Show("Запись Удалена!");
            }
            catch
            {
                MessageBox.Show("Ошибка! Запись не Удалена!");
            }
            if (Connect.connection.State.Equals(ConnectionState.Open)) CloseConnect();
        }
        public static void AddPH(string PH_Name, string PH_Address, string PH_Number)//Класс для добавления записи в таблицу publishing_houses
        { 
            try
                {
                    connection = new MySqlConnection(connString);
                    connection.Open();
                    MySqlCommand cm = new MySqlCommand("INSERT INTO publishing_houses (PH_Name, PH_Address, PH_Number) VALUES (@PH_Name, @PH_Address, @PH_Number)", connection);//Создание запроса
                    cm.Parameters.Add("@PH_Name", MySqlDbType.VarChar, 30).Value = Convert.ToString(PH_Name);//добавление записей в таблицу publishing_houses
                    cm.Parameters.Add("@PH_Address", MySqlDbType.VarChar, 30).Value = Convert.ToString(PH_Address);
                    cm.Parameters.Add("@PH_Number", MySqlDbType.VarChar, 11).Value = Convert.ToString(PH_Number);
                    cm.ExecuteNonQuery();
                    MessageBox.Show("Запись создана!");
                }
                catch
                {
                    MessageBox.Show("Ошибка! Запись не создана!");
                }
                CloseConnect();            
        }
        public static void CloseConnect()
        {
            if (connection.State == System.Data.ConnectionState.Open)
            {
                connection.Close();
            }
        }
        public static void EndConnect()
        {
            CloseConnect();
            connName = null;
            connString = null;
        }
        public static string GetName()
        {
            return connName;
        }     
        public static int GetId(string Name_Id, string table, string param, string value)
        {          
            int id = 0; // выполнение команды и получение кл-ва записей с опр. id в опр. таблице  
            if (!Connect.connection.State.Equals(ConnectionState.Open)) Connect.OpenConnect();
            string sql = "SELECT " + Name_Id + " FROM " + table + " WHERE " + param + " = '" + value + "' ";
            MySqlCommand cmd = new MySqlCommand(sql, Connect.connection);
            using (cmd)
            {
                id = Convert.ToInt32(cmd.ExecuteScalar());
            }
            cmd.ExecuteNonQuery();
            if (Connect.connection.State.Equals(ConnectionState.Open)) Connect.CloseConnect();
            return id;
        }
        public static int GetId_FIO(string table, string FIO)
        {
            string sql = "запрос", F, I, O;
            int k = 0, k1 = 0, k2 = 0;
            int id = 0; // выполнение команды и получение кл-ва записей с опр. id в опр. таблице
            for (int i = 0; i < FIO.Length; i++)
            {
                if (FIO[i] == ' ')
                {
                    k++;
                    if (k == 1) k1 = i;
                    if (k == 2) k2 = i;
                }
            }
            if (k == 2)
            {
                F = FIO.Substring(0, k1);
                I = FIO.Substring(k1 + 1, k2 - k1 - 1);
                O = FIO.Substring(k2 + 1, FIO.Length - k2 - 1);
                Connect.OpenConnect();
                if (table == "authors") sql = "SELECT Author_Id FROM authors WHERE Author_SecondName =@f " +
                " and Author_FirstName=@i and Author_Patronymic= @o";
                if (table == "librarians") sql = "SELECT Librarian_Id FROM librarians WHERE Librarian_SecondName=@f " +
                " and Librarian_FirstName=@i and Librarian_Patronymic = @o";
                if (table == "clients")
                    sql = "SELECT Client_Id FROM clients WHERE Client_SecondName=@f " +
                    " and Client_FirstName=@i and Client_Patronymic=@o";
                using (MySqlCommand cmd = new MySqlCommand(sql, Connect.connection))
                {
                    cmd.Parameters.Add("@f", MySqlDbType.VarChar, 15).Value = F;//добавление записей в таблицу librarians
                    cmd.Parameters.Add("@i", MySqlDbType.VarChar, 15).Value = I;
                    cmd.Parameters.Add("@o", MySqlDbType.VarChar, 15).Value = O;
                    id = Convert.ToInt32(cmd.ExecuteScalar());
                }
                Connect.CloseConnect();
            }
            return id;
        }
        
        public static ObservableCollection<AuthorFIO> ChtoToForComboBox(string table)
        {
            string sql = "запрос";
            ObservableCollection<AuthorFIO> authors = new ObservableCollection<AuthorFIO>();
            List <String> fio = new List<String>();
            if (!Connect.connection.State.Equals(ConnectionState.Open)) Connect.OpenConnect();
            switch(table)
            {
                case "authors":
                    sql = "SELECT Author_Id, Author_SecondName, Author_FirstName, Author_Patronymic FROM authors";
                    fio = new List<string>() { "Author_Id", "Author_SecondName", "Author_FirstName", "Author_Patronymic" };
                    break;
                case "librarians":
                    sql = "SELECT Librarian_Id, Librarian_SecondName, Librarian_FirstName, Librarian_Patronymic FROM librarians";
                    fio = new List<string>() { "Librarian_Id", "Librarian_SecondName", "Librarian_FirstName", "Librarian_Patronymic" };
                    break;
                case "clients":
                    sql = "SELECT Client_Id, Client_SecondName, Client_FirstName, Client_Patronymic FROM clients";
                    fio = new List<string>() { "Client_Id", "Client_SecondName", "Client_FirstName", "Client_Patronymic" };
                    break;
                case "redings":
                    sql = "SELECT Read_Id, Read_Title  FROM readings";
                    fio = new List<string>() { "Read_Id", "Read_Title" };
                    break;
                case "publishing_houses":
                    sql = "SELECT PH_Id, PH_Name  FROM publishing_houses";
                    fio = new List<string>() { "PH_Id", "PH_Name" };
                    break;
                case "libraries":
                    sql = "SELECT Library_Id, Library_Name  FROM libraries";
                    fio = new List<string>() { "Library_Id", "Library_Name" };
                    break;
                case "books":
                    sql = "SELECT Book_Id, Book_PublNumber  FROM books";
                    fio = new List<string>() { "Book_Id", "Book_PublNumber" };
                    break;
                case "ebooks":
                    sql = "SELECT Read_ID, Read_Title FROM readings, ebooks WHERE Read_Id = Ebook_Id";
                    fio = new List<string>() { "Read_ID", "Read_Title" };
                    break;
                case "journals":
                    sql = "SELECT Read_ID, Read_Title FROM readings, journals WHERE Read_Id = Journal_Id";
                    fio = new List<string>() { "Read_ID", "Read_Title" };
                    break;
            };
            using (MySqlCommand cmd = new MySqlCommand(sql, Connect.connection))
            {
                MySqlDataReader reader = cmd.ExecuteReader();
                while(reader.Read())
                {
                    String disp;
                    if (fio.Count == 3)
                    {
                        disp = reader[fio.ElementAt(1)].ToString() + reader[fio.ElementAt(2)].ToString()[0] + reader[fio.ElementAt(3)].ToString()[0];

                    }
                    else disp = reader[fio.ElementAt(1)].ToString();
                    authors.Add(new AuthorFIO((int)reader[fio.ElementAt(0)], disp));
                }
                reader.Close();
            }
            Connect.CloseConnect();
            return authors;
        }



    }
}
