﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace LIBproject
{
    /// <summary>
    /// Логика взаимодействия для AddJournal.xaml
    /// </summary>
    public partial class AddJournal : Page
    {
        public AddJournal()
        {
            InitializeComponent();
            Authors.ItemsSource = Connect.ChtoToForComboBox("authors");
            Libraries.ItemsSource = Connect.ChtoToForComboBox("libraries");
            Izdatelstva.ItemsSource = Connect.ChtoToForComboBox("publishing_houses");
        }
        private void Button_Click_1(object sender, RoutedEventArgs e)//кнопка добавления записи
        {
                int PH_Id; int Library_Id; int Author_Id;
            PH_Id = Convert.ToInt32(Izdatelstva.SelectedValue);
            Library_Id = Convert.ToInt32(Libraries.SelectedValue);
            Author_Id = Convert.ToInt32(Authors.SelectedValue);
            Connect.AddJournal(TextBox1.Text, TextBox2.Text, PH_Id, Library_Id, Author_Id, TextBox6.Text, TextBox7.Text); //вызов класса из файла connect.cs
        }
    }
}
