﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace LIBproject
{
    /// <summary>
    /// Логика взаимодействия для DelInf.xaml
    /// </summary>
    public partial class DelInf : Window
    {
        public DelInf()
        {
            InitializeComponent();
        }
        private void Button_Click(object sender, RoutedEventArgs e)//По нажатию кнопки возврат в главное меню
        {
            this.Hide();
            MainWindow back = new MainWindow();
            back.Show();
        }
        //при выборе элемента в комбоБокс откроется страницы для добавления в соот-щую таблицу
        private void ComboBoxItem_Selected(object sender, RoutedEventArgs e)//таблица книг
        {
            MainFrame.Content = new delbook();
        }

        private void ComboBoxItem_Selected_1(object sender, RoutedEventArgs e)//таблица авторов
        {
            MainFrame.Content = new delauthor();
        }

        private void ComboBoxItem_Selected_2(object sender, RoutedEventArgs e)//таблица ел.книг
        {
            MainFrame.Content = new delebook();
        }

        private void ComboBoxItem_Selected_3(object sender, RoutedEventArgs e)//таблица библиотек
        {
            MainFrame.Content = new dellibrary();
        }

        private void ComboBoxItem_Selected_4(object sender, RoutedEventArgs e)//таблица библиотекарей
        {
            MainFrame.Content = new dellibrarian();
        }

        private void ComboBoxItem_Selected_5(object sender, RoutedEventArgs e)//таблица журналов
        {
            MainFrame.Content = new deljournal();
        }

        private void ComboBoxItem_Selected_6(object sender, RoutedEventArgs e)//таблица издательств
        {

            MainFrame.Content = new delPH();
        }

        private void ComboBoxItem_Selected_7(object sender, RoutedEventArgs e)//таблица клиентов
        {

            MainFrame.Content = new delclient();
        }

        private void ComboBoxItem_Selected_8(object sender, RoutedEventArgs e)//таблица аренды
        {

            MainFrame.Content = new delrental();
        }
    }
}
    
