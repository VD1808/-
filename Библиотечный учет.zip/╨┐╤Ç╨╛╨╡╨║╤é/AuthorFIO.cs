﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LIBproject
{
    public class AuthorFIO { 
    
    public int id { set; get; }


    public string displayed { set; get; }

    public AuthorFIO(int id,  string displayed)
        {
            this.id = id;
            this.displayed = displayed;//Author_SecondName + " " + Author_FirstName[0] + " " + Author_Patronymic[0];
        }
    }
}
