﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using LIBproject;

namespace LIBproject
{
    /// <summary>
    /// Логика взаимодействия для ConnectWindow.xaml
    /// </summary>
    public partial class ConnectWindow : Window
    {
        public ConnectWindow()
        {
            InitializeComponent();
            ConnectName.Text = "";
            HostName.Text = "";
            Port.Text = "";
            Login.Text = "";
            Pwd.Password = "";

        }

        private void ConnectButton_Click(object sender, RoutedEventArgs e)
        {
            if((ConnectName.Text !="")|| (HostName.Text != null) || (Port.Text != null) || (Login.Text != null) || (Pwd.Password != null))
            {
                
                Connect.CreateConnect(ConnectName.Text, HostName.Text, Port.Text, Login.Text,Pwd.Password);
                
                try
                {
                    Connect.OpenConnect();
                    MessageBox.Show("Соединение установлено");
                }
                catch
                {
                    MessageBox.Show("Ошибка подключения\n (На серевере должна присутствовать БД 'lib')");
                    Connect.EndConnect();
                }
                finally
                {
                    Connect.CloseConnect();
                }
            }
            else
            {
                MessageBox.Show("Введите параметры!");
            }
        }

        private void BackButton_Click(object sender, RoutedEventArgs e)
        {
            Close();
        }

        private void StopButton_Click(object sender, RoutedEventArgs e)
        {

            Connect.EndConnect();
        }

        private void Status_Click(object sender, RoutedEventArgs e)
        {
            if(Connect.GetName()!=null)
            {
                MessageBox.Show("Установлено соединение: "+ Connect.GetName());
            }
            else
            {
                MessageBox.Show("Cоединение отсутствует");
            }
        }
    }
}
