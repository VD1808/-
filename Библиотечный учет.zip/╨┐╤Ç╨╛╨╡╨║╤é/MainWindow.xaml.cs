﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using LIBproject;

namespace LIBproject
{
    /// <summary>
    /// Логика взаимодействия для MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        
        public MainWindow()
        {
            InitializeComponent();
        }

        private void ConnectButton_Click(object sender, RoutedEventArgs e)
        { //окно настройки соединения
            ConnectWindow w = new ConnectWindow();
            w.Show();
        }

        private void CreateButton_Click(object sender, RoutedEventArgs e)
        { //проверяем присутствует ли соединение
            if (Connect.GetName() != null)//если нет названия, то и содеинения нет
           {
                this.Hide();
                AddInf AddInformation = new AddInf();
                AddInformation.Show();
            }
            else
            {
               MessageBox.Show("Cоединение отсутствует");
            }
        }

        private void ReadButton_Click(object sender, RoutedEventArgs e)
        { //окно вывода
            if (Connect.GetName() != null)
            {
                ViewWindow w = new ViewWindow();
                w.Show();
           }
            else
            {
              MessageBox.Show("Cоединение отсутствует");
            }
        }

        private void UpdateButton_Click(object sender, RoutedEventArgs e)
        { //открытие окна обновления
            if (Connect.GetName() != null)
            {
                TablesWindow w = new TablesWindow();
                w.Show();
            }
            else
            {
                MessageBox.Show("Cоединение отсутствует");
            }
        }

        private void DeleteButton_Click(object sender, RoutedEventArgs e)
        { //окно удаления
            if (Connect.GetName() != null)
            {
                // функциoнал удаления записей
                this.Hide();
                DelInf DeleteInformation = new DelInf();
                DeleteInformation.Show();
            }
            else
            {
                MessageBox.Show("Cоединение отсутствует");
            }
        }
    }
}
