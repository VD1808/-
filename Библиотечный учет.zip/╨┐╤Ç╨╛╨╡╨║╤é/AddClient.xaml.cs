﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace LIBproject
{
    /// <summary>
    /// Логика взаимодействия для AddClient.xaml
    /// </summary>
    public partial class AddClient : Page
    {
        public AddClient()
        {
            InitializeComponent();
            Libraries.ItemsSource = Connect.ChtoToForComboBox("libraries");
        }
        private void Button_Click(object sender, RoutedEventArgs e)//кнопка добавления записи
        {
                int id;
                id = Convert.ToInt32(Libraries.SelectedValue);
            Connect.AddClient(TextBox1.Text, TextBox2.Text, TextBox3.Text, TextBox4.Text, id);//вызов класса из файла connect.cs
        }
    }
}
