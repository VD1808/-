﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Data;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using MySql.Data.MySqlClient;

namespace LIBproject
{
    /// <summary>
    /// Логика взаимодействия для ViewWindow.xaml
    /// </summary>
    public partial class ViewWindow : Window
    {
        string status = null;
        public ViewWindow()
        {
            InitializeComponent();
           
        }

        public void ShowView(string view)
        { //вывод представления
            if (!Connect.connection.State.Equals(ConnectionState.Open)) Connect.OpenConnect();
            string sql = "SELECT * FROM " + view;
            using (MySqlCommand cmd = new MySqlCommand(sql, Connect.connection))
            {
                DataTable dt = new DataTable();
                MySqlDataAdapter da = new MySqlDataAdapter(cmd);
                da.Fill(dt);
                DataView.ItemsSource = dt.DefaultView;
                if(Connect.connection.State.Equals(ConnectionState.Open)) Connect.CloseConnect(); 
            }
            if (Connect.connection.State.Equals(ConnectionState.Open)) Connect.CloseConnect();
        }

        private void ShowBooksView(object sender, RoutedEventArgs e)
        {
            ShowView("books");
            Label.Content = "";
            ShowButton.Content = "";
            status = null;
        }

        private void ShowAuthorsView(object sender, RoutedEventArgs e)
        {
            ShowView("authors");
            Label.Content = "";
            ShowButton.Content = "";
            status = null;
        }

        private void ShowEbooksView(object sender, RoutedEventArgs e)
        {
            ShowView("ebooks");
            Label.Content = "";
            ShowButton.Content = "";
            status = null;
        }

        private void ShowLibrariesView(object sender, RoutedEventArgs e)
        {
            ShowView("libraries");
            Label.Content = "";
            ShowButton.Content = "";
            status = null;
        }

        private void ShowLibrariansView(object sender, RoutedEventArgs e)
        {
            ShowView("librarians");
            Label.Content = "";
            ShowButton.Content = "";
            status = null;
        }

        private void ShowJournalsView(object sender, RoutedEventArgs e)
        {
            ShowView("journals");
            Label.Content = "";
            ShowButton.Content = "";
            status = null;
        }

        private void ShowPublHousesView(object sender, RoutedEventArgs e)
        {
            ShowView("publishing_houses");
            Label.Content = "";
            ShowButton.Content = "";
            status = null;
        }

        private void ShowClientsView(object sender, RoutedEventArgs e)
        {
            ShowView("clients");
            Label.Content = "";
            ShowButton.Content = "";
            status = null;
        }

        private void ShowRentalsView(object sender, RoutedEventArgs e)
        {
            ShowView("rentals");
            Label.Content = "";
            ShowButton.Content = "";
            status = null;
        }

        private void ShowReadInStock(object sender, RoutedEventArgs e)
        {
            status="В наличии";
            Label.Content = "Введите название";
            ShowButton.Content = "Вывести";
        }

        public void ReadingsWithStatus(string status, int lib_id)
        { //вывод нескольких атрибутов чтива + тип
            DataTable dt;
            Connect.OpenConnect();
            string sql="запрос";
            if (status == "В наличии") sql = "Select Read_Id, Read_Title, Read_Pages, 'тип' as Тип from readings where Read_Status='" + status + "'" +
                  "and Library_id=" + lib_id;
            else sql= "Select readings.Read_Id, Read_Title, Read_Pages, 'тип' as Тип, Rent_StartDate as 'Дата начала', Rent_ReturnDate as 'Дата возврата' " +
                    "from readings,rentals where Read_Status='" + status + "' " +
                  "and readings.Library_id=" + lib_id + " and readings.Read_Id=rentals.Read_id"; 
            using (MySqlCommand cmd = new MySqlCommand(sql, Connect.connection))
            {
                dt = new DataTable();
                MySqlDataAdapter da = new MySqlDataAdapter(cmd);
                da.Fill(dt);
                DataView.ItemsSource = dt.DefaultView;
            }
            Connect.CloseConnect();
            int index = 0; //проходимся по всем строкам с помощью индекса
            foreach (DataRowView row in DataView.ItemsSource) // получение всех строк из датагрид
            {
                int Id = Convert.ToInt32(row.Row[0]); // получение id записи
                dt.Rows[index].SetField(3, ReadType(Id));
                index++;
            }
            DataView.ItemsSource = dt.DefaultView;
        }

        private string ReadType(int id) //проверяем есть ли запись с таким id
        { // в одной из таблиц: книги, журналы и эл. книги
            string type="тип";
            string sql = "select count(*) from books where Book_Id="+id; // есть ли книга с таким id
            if (GetCount(sql) == 1) type = "Книга";
            sql = "select count(*) from ebooks where Ebook_Id=" + id; // есть ли эл. книга с таким id
            if (GetCount(sql) == 1) type = "Эл. книга";
            sql = "select count(*) from journals where Journal_Id=" + id; // есть ли журнал с таким id
            if (GetCount(sql) == 1) type = "Журнал";
            return type;

        }
        private int GetCount(string sql)
        {
            int count = 0; // выполнение команды и получение кл-ва записей с опр. id в опр. таблице
            Connect.OpenConnect();
            using (MySqlCommand cmd = new MySqlCommand(sql, Connect.connection))
            {
                count = Convert.ToInt32(cmd.ExecuteScalar());
            }
            Connect.CloseConnect();
            return count;
        }

        private void ShowReadIssued(object sender, RoutedEventArgs e)
        { //выбор запроса на выданную литературу
            status="Выдано";
            Label.Content = "Введите название";
            ShowButton.Content = "Вывести";
        }

        private int LibraryExistense(string lib_name)
        { //проверка на сущестование библиотеки
            string sql = "select count(*) from libraries where Library_Name='" + lib_name+"'"; // есть библиотека с таким названием
            int id = 0;
            if (GetCount(sql) == 0)
            {
                return 0; //если нет такой, то возвращает 0
            }
            else
            {
                sql = "select Library_Id from libraries where Library_Name='" + lib_name + "'";
                Connect.OpenConnect();
                using (MySqlCommand cmd = new MySqlCommand(sql, Connect.connection))
                { //иначе получение id и функция возвращает его
                    id = Convert.ToInt32(cmd.ExecuteScalar());
                }
                Connect.CloseConnect();
                return id;
            }
        }

        private void ShowButton_Click(object sender, RoutedEventArgs e)
        { //если текстбокс пустой, то показывает месседжбокс
            if (status!=null)
            {
                if (TextBox.Text == null) MessageBox.Show("Введите название!");
                else
                { //иначе проверка на существование и выполненеие запроса
                    if (LibraryExistense(TextBox.Text) == 0) MessageBox.Show("Библиотека с таким названием не существует!");
                    else
                    {
                        ReadingsWithStatus(status, LibraryExistense(TextBox.Text));
                        DataView.Columns[0].Header = "Id";
                        DataView.Columns[1].Header = "Название";
                        DataView.Columns[2].Header = "Кол-во страниц";
                    }
                }
            }

        }
    }
}
