﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace LIBproject
{
    /// <summary>
    /// Логика взаимодействия для AddLibrarian.xaml
    /// </summary>
    public partial class AddLibrarian : Page
    {
        public AddLibrarian()
        {
            InitializeComponent();
            Libraries.ItemsSource = Connect.ChtoToForComboBox("libraries");
        }
        private void Button_Click_1(object sender, RoutedEventArgs e)//кнопка добавления записи
        {          
                int id;
                id = Convert.ToInt32(Libraries.SelectedValue);
            Connect.Addlibrarians(TextBox1.Text, TextBox2.Text, TextBox3.Text, TextBox4.Text, id);//вызов класса из файла connect.cs
        }
    }
}
