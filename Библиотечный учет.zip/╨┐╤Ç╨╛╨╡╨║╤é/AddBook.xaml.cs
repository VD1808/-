﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace LIBproject
{
    /// <summary>
    /// Логика взаимодействия для AddBook.xaml
    /// </summary>
    public partial class AddBook : Page
    {
        public AddBook()
        {
            InitializeComponent();

            Authors.ItemsSource = Connect.ChtoToForComboBox("authors");
            Libraries.ItemsSource = Connect.ChtoToForComboBox("libraries");
            Izdatelstva.ItemsSource = Connect.ChtoToForComboBox("publishing_houses");
        }

        private void Button_Click_1(object sender, RoutedEventArgs e)//кнопка добавления записи
        {

                int PH_Id; int Library_Id; int Author_Id;
                PH_Id = Convert.ToInt32(Izdatelstva.SelectedValue);
            Library_Id = Convert.ToInt32(Libraries.SelectedValue);
            Author_Id = Convert.ToInt32(Authors.SelectedValue);
                Connect.AddBook(TextBox1.Text, TextBox2.Text, PH_Id, Library_Id, Author_Id, TextBox6.Text, TextBox7.Text); //вызов класса из файла connect.cs


        }

        private void Authors_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
           // TextBox9.Text = Authors.SelectedValue.ToString();
        }

        private void Authors_Drop(object sender, DragEventArgs e)
        {
            
        }

        private void Authors_DropDownOpened(object sender, EventArgs e)
        {
        }
        private void Lib_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
          //  TextBox4.Text = Libraries.SelectedValue.ToString();
        }

        private void Izd_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
           // TextBox3.Text = Izdatelstva.SelectedValue.ToString();
        }
    }
}
