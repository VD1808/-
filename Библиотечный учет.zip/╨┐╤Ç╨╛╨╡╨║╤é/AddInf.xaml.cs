﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace LIBproject
{
    /// <summary>
    /// Логика взаимодействия для AddInf.xaml
    /// </summary>
    public partial class AddInf : Window
    {
        public AddInf()
        {
            InitializeComponent();
        }
        private void Button_Click(object sender, RoutedEventArgs e)//Возврат на главное окно по нажатию кнопки
        {
            this.Hide();
            MainWindow back = new MainWindow();
            back.Show();
        }
        //при выборе элемента в комбоБокс откроется страницы для добавления в соот-щую таблицу
        private void ComboBoxItem_Selected(object sender, RoutedEventArgs e)//таблица книг
        {
            MainFrame.Content = new AddBook();
        }

        private void ComboBoxItem_Selected_1(object sender, RoutedEventArgs e)//таблица авторов
        {
            MainFrame.Content = new AddAuthor();
        }

        private void ComboBoxItem_Selected_2(object sender, RoutedEventArgs e)//таблица эл.книг
        {
            MainFrame.Content = new AddEbook();
        }

        private void ComboBoxItem_Selected_3(object sender, RoutedEventArgs e)//таблица библиотек
        {
            MainFrame.Content = new AddLibrary();
        }

        private void ComboBoxItem_Selected_4(object sender, RoutedEventArgs e)//таблица библиотекарей
        {
            MainFrame.Content = new AddLibrarian();
        }

        private void ComboBoxItem_Selected_5(object sender, RoutedEventArgs e)//таблица журналов
        {
            MainFrame.Content = new AddJournal();
        }

        private void ComboBoxItem_Selected_6(object sender, RoutedEventArgs e)//таблица издательств
        {

            MainFrame.Content = new AddPH();
        }

        private void ComboBoxItem_Selected_7(object sender, RoutedEventArgs e)//таблица клиентов
        {

            MainFrame.Content = new AddClient();
        }

        private void ComboBoxItem_Selected_8(object sender, RoutedEventArgs e)//таблица аренды
        {

            MainFrame.Content = new AddRental();
        }


    }
}
    
