﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Webapi.Models.Employees;

namespace Webapi.Models.Employees
{
    public class WorkExpirience
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]

        public int Id { get; set; }
        public int WorkedYears {  get; set; } = 0;
        public int? Description { get; set; } = null;
       // public Employee Employee { get; set; }  
        
    }
}
