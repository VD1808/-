﻿namespace Webapi.Models.DTO
{
    public class RegisterRequestDto
    {
        public string Login { get; set; }
        public string Password { get; set; }
    }
}
