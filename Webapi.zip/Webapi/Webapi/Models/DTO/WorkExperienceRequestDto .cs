﻿using Webapi.Models.Employees;

namespace Webapi.Models.DTO
{
    public class WorkExperienceRequetDto
    {
        public int EmployeeId { get; set; }
        public int WorkedYears { get; set; } = 0;
        public int? Description { get; set; } = null;


    }
}
