﻿namespace Webapi.Models.DTO
{
    public class DownloadFileRequestDto
    {
        public string SystemName { get; set; }
        public string DisplayName { get; set; }
    }
}
