﻿namespace Webapi.Models.DTO
{
    public class FileRequestDto
    {
        public string FileString { get; set; }
        public string FileName { get; set; }
        public int EmployeeId { get; set; }
    }
}
