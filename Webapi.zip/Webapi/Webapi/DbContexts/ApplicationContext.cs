﻿using Microsoft.EntityFrameworkCore;
using Webapi.Models.Departments;
using Webapi.Models.Employees;
using Webapi.Models.Users;

namespace Webapi.DbContexts
{
    public class ApplicationContext: DbContext
    {
        public DbSet<User> Users { get; set; } = null;
        public DbSet<Department> Departments { get; set; } = null;
        public DbSet<Employee> Employees { get; set; } = null;
        public DbSet<Education> Educations { get; set; } = null;
        public DbSet<WorkExpirience> WorkExpirience { get; set; } = null;
        public DbSet<UserFile> UserFiles { get; set; } = null;

        public ApplicationContext() 
        {
            //Database.EnsureCreated();
        }
        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            //base.OnConfiguring(optionsBuilder);
            optionsBuilder.UseNpgsql("Host=localhost; Port=5432; Database = WebapiDb; Username=postgres; Password=2017044257");
        }
    }
}
