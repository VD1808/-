﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Webapi.DbContexts;
using Webapi.Models.DTO;
using Webapi.Models.Employees;

namespace Webapi.Controllers
{
    [ApiController]
    [Route("[controller]")]
    [Authorize]

    public class EmployeesController : ControllerBase
    {
        private ApplicationContext _context;

        public EmployeesController()
        {
            _context = new ApplicationContext();
        }

        [HttpGet("employee")]
        [Authorize(Roles = "admin, manager")]
        public IEnumerable<Employee> GetEmployees()
        {
            return _context.Employees.Include(e => e.WorkExpirience).Include(e => e.Educations).Include(e => e.UserFiles).ToList();
        }

        [HttpPost("employee")]
        [Authorize(Roles = "admin, manager")]
        public IActionResult CreateEmployee([FromBody] EmployeeRequastDto employeeDto)
        {
            var department = _context.Departments.Include(d => d.Employees)
                .FirstOrDefault(d => d.Id == employeeDto.DepartmentID);
            if (department != null)
            {
                var _employee = _context.Employees.Add(new Employee
                {
                    BirthDate = employeeDto.BirthDate,
                    Email = employeeDto.Email,
                    FirstName = employeeDto.FirstName,
                    LastName = employeeDto.LastName,
                    MidlName = employeeDto.MidlName,
                    PhoneNumber = employeeDto.PhoneNumber,

                });

                _context.SaveChanges();

                if (department.Employees == null)
                {
                    department.Employees = new List<Employee>();
                }
                department.Employees.Add(_employee.Entity);

                _context.SaveChanges();

                return Ok(_employee.Entity.Id);
            }
            return BadRequest("Depatment not found");

        }

        [HttpPut("employee")]
        [Authorize(Roles = "admin, manager")]
        public IActionResult UpdateEmployee([FromBody] Employee employee)
        {
            var _employee = _context.Employees.FirstOrDefault(e => e.Id == employee.Id);
            if (_employee != null)
            {
                _employee.BirthDate = employee.BirthDate;
                _employee.Email = employee.Email;
                _employee.FirstName = employee.FirstName;
                _employee.LastName = employee.LastName;
                _employee.MidlName = employee.MidlName;
                _employee.PhoneNumber = employee.PhoneNumber;
                _context.SaveChanges();

                return Ok();
            }

            return BadRequest("Employee not found");
        }

        [HttpDelete("employee")]
        [Authorize(Roles = "admin, manager")]
        public IActionResult DeleteEmployee(int id)
        {
            var _employee = _context.Employees.FirstOrDefault(e => e.Id == id);
            if (_employee != null)
            {
                _context.Employees.Remove(_employee);
                _context.SaveChanges();
                return Ok();
            }
            return BadRequest("Employee not found");
        }

        [HttpPost("workexperience")]
        [Authorize(Roles = "admin, manager")]
        public IActionResult AddWorkExperience([FromBody] WorkExperienceRequetDto workExperience)
        {
            var _employee = _context.Employees.FirstOrDefault(e => e.Id == workExperience.EmployeeId);
            if (_employee != null)
            {
                if (_employee.WorkExpirience == null)
                {
                    _employee.WorkExpirience = new List<WorkExpirience>();
                }
                _employee.WorkExpirience.Add(new WorkExpirience
                {
                    Description = workExperience.Description,
                    WorkedYears = workExperience.WorkedYears,
                });
                _context.SaveChanges();

                var weId = _employee.WorkExpirience.LastOrDefault()?.Id ?? 0;

                return Ok(weId);
            }
            return BadRequest("Employee not found");
        }
        [HttpDelete("workexpirience")]
        [Authorize(Roles = "admin, manager")]
        public IActionResult DeletWorkExpirience(int id)
        {
            var _workExpirience = _context.WorkExpirience.FirstOrDefault(we => we.Id == id);
            if (_workExpirience != null)
            {
                _context.WorkExpirience.Remove(_workExpirience);
                _context.SaveChanges();
                return Ok();
            }
            return BadRequest("Work expirience entry not found");
        }

        [HttpPost("education")]
        [Authorize(Roles = "admin, manager")]
        public IActionResult AddEducation([FromBody] EducationRequastDto education)
        {
            var _employee = _context.Employees.FirstOrDefault(e => e.Id == education.EmployeeId);
            if (_employee != null)
            {
                if (_employee.Educations == null)
                {
                    _employee.Educations = new List<Education>();
                }
                _employee.Educations.Add(new Education
                {
                    Description = education.Description,
                    Title = education.Title,
                });
                _context.SaveChanges();
                
                var edId = _employee.Educations.LastOrDefault()?.Id ?? 0;

                return Ok(edId);
            }
            return BadRequest("Employee not found");
        }
        [HttpDelete("education")]
        [Authorize(Roles = "admin, manager")]
        public IActionResult DeletEducation(int id)
        {
            var _education = _context.Educations.FirstOrDefault(we => we.Id == id);
            if (_education != null)
            {
                _context.Educations.Remove(_education);
                _context.SaveChanges();
                return Ok();
            }
            return BadRequest("Work expirience entry not found");
        }

    }
}

