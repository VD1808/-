﻿using Microsoft.IdentityModel.Tokens;
using System.Text;

namespace Webapi
{
    public class AuthOptions
    {
        /// <summary>
        /// Издатель токена
        /// </summary>
        public const string ISSUER = "WebAPI_App_server";
        /// <summary>
        /// Потребитель токена
        /// </summary>
        public const string AUDIENCE = "WebAPI_App_Client";
        /// <summary>
        /// Ключ шифрования
        /// </summary>
        public const string KEY = "6A3202ED-2311-418F-81E4-75A03F12A938";
        /// <summary>
        /// Время жизни токена
        /// </summary>
        public const int LIFETIME = 480;

        public static SymmetricSecurityKey GetSymmetricSecurityKey() 

        {
            return new SymmetricSecurityKey(Encoding.ASCII.GetBytes(KEY));
        }
    }
}
